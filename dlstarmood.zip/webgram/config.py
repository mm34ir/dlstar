import os 

class Config:
    # noinspection PyPep8Naming
    class config:
        APP_ID = 50807

        API_HASH = "21ab7cb0a453b5e60016dc7bbeb701cb"

        SESS_NAME = "dlstar_bot_client"
        
        SESS_NAME2 = "dlstar_bot_client2"
        
        BOT_TOKEN = "1215711283:AAFuct-4Kd1-cDaWp4rLENN08oxgNSOx7FI"
        
        BOT_TOKEN2 = "1065536817:AAHpPpHQVOGprLOG517xuqDeba4wECwxnUg"
        
        MASTER_TOKEN = "1BJWap1wBuxFR8XNktvoxlvc5Pqhnkx8sOdTgrPu4VKfn5mAraUOjYVWTY1_a7RJ2gOCpDY9dt9IHdSLh5KNCa5Hub3yzQe2KXOGDNb_FtyueWb_r086ukPNXe86VQ3BDC8CVPupvWQL66RNkTp_WQ4fS2Y2M8Uv8CMEO-9WFb_GIQDCpAN-JANYP5rTOQvfDPWbvIipibXeD0h5KuUCPfYuyAeS38xajvvN5yuGoMeAShYQG9htW4Wwe0wcKk6uw3L3Qpxnh2v5gf9sfFkLVk39u7ELRyH7eOlHJVACyCTdVj8VMS-RrXR9Q-kDBU3f_AeGHqO3KcebEaSS0hwLuoaeei0Vt9wY="
        
        channel = 'UserlandApp'

        STATS_CHANNEL = -1001249461809
        
        CONFIG_CHANNEL = -1001428583293

        HOST = "127.0.0.1"

        PORT = os.getenv('PORT')

        ROOT_URI = f"http://dlstarus.dlgram.ml"

        ROOT_URI_2 = "http://dlstarir.dlgram.ml"
        
        ROOT_URI_3 = "http://ali.dlgram.ml"

        ENCODING = "utf8"


        # ALLOWED_EXT = ["mkv", "mp4", "flv"]
